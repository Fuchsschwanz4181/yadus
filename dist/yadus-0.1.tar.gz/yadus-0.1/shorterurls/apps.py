from django.apps import AppConfig


class ShorterurlsConfig(AppConfig):
    name = 'shorterurls'
